﻿using System;
using System.Data;
using System.Windows;
using ComputerEquipmentAccounting.Services;

namespace ComputerEquipmentAccounting.Views
{
    public partial class MainWindow : Window
    {
        private readonly DatabaseService _dbService;

        public MainWindow()
        {
            InitializeComponent();
            _dbService = new DatabaseService();
            LoadData();
            txtStatus.Text = "Готов";
        }

        private void LoadData()
        {
            dgEquipment.ItemsSource = _dbService.GetAllEquipment().DefaultView;
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            LoadData();
            txtSearch.Text = "";
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtSearch.Text))
            {
                LoadData();
                return;
            }
            dgEquipment.ItemsSource = _dbService.SearchEquipment(txtSearch.Text).DefaultView;
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            var addWindow = new EquipmentEditWindow();
            addWindow.ShowDialog();
            LoadData();
        }

        private void BtnMove_Click(object sender, RoutedEventArgs e)
        {
            if (dgEquipment.SelectedItem == null)
            {
                MessageBox.Show("Выберите оборудование для перемещения", "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var row = (DataRowView)dgEquipment.SelectedItem;
            int equipmentId = Convert.ToInt32(row["Id"]);  // ← Исправлено!

            var moveWindow = new MovementWindow(equipmentId);
            moveWindow.ShowDialog();
            LoadData();
        }

        private void BtnRepair_Click(object sender, RoutedEventArgs e)
        {
            if (dgEquipment.SelectedItem == null)
            {
                MessageBox.Show("Выберите оборудование для создания заявки", "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var row = (DataRowView)dgEquipment.SelectedItem;
            int equipmentId = Convert.ToInt32(row["Id"]);      // ← Исправлено!
            string equipmentName = row["Name"].ToString();

            var repairWindow = new RepairRequestWindow(equipmentId, equipmentName);
            repairWindow.ShowDialog();
            LoadData();
        }
    }
}