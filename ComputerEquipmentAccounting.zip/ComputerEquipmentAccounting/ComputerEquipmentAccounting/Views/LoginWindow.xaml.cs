﻿using System.Windows;
using ComputerEquipmentAccounting.Services;

namespace ComputerEquipmentAccounting.Views
{
    public partial class LoginWindow : Window
    {
        private readonly AuthService _authService;
        private readonly DatabaseService _dbService;

        public LoginWindow()
        {
            InitializeComponent();
            _authService = new AuthService();
            _dbService = new DatabaseService();
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            string login = txtLogin.Text.Trim();
            string password = txtPassword.Password;

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                txtError.Text = "Введите логин и пароль";
                return;
            }

            var user = _authService.Authenticate(login, password);

            if (user != null)
            {
                App.CurrentUser = user;

                var mainWindow = new MainWindow();
                mainWindow.Show();
                this.Close();
            }
            else
            {
                txtError.Text = "Неверный логин или пароль";
                txtPassword.Password = "";
            }
        }

        private void BtnExit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}