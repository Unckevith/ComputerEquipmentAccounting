﻿using System;
using System.Windows;
using ComputerEquipmentAccounting.Services;

namespace ComputerEquipmentAccounting.Views
{
    public partial class MovementWindow : Window
    {
        private readonly DatabaseService _db;
        private readonly int _equipmentId;

        public MovementWindow(int equipmentId)
        {
            InitializeComponent();
            _db = new DatabaseService();
            _equipmentId = equipmentId;
            LoadLocations();
        }

        private void LoadLocations()
        {
            var locations = _db.GetLocations();
            locations.Columns.Add("FullAddress", typeof(string), "Building + ', каб.' + RoomNumber");
            cmbLocation.ItemsSource = locations.DefaultView;
            cmbLocation.DisplayMemberPath = "FullAddress";
            cmbLocation.SelectedValuePath = "Id";
            if (locations.Rows.Count > 0) cmbLocation.SelectedIndex = 0;
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            if (cmbLocation.SelectedValue == null)
            {
                MessageBox.Show("Выберите новый кабинет", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            int newLocationId = Convert.ToInt32(cmbLocation.SelectedValue);

            bool result = _db.MoveEquipment(_equipmentId, newLocationId, "");

            if (result)
            {
                MessageBox.Show("Оборудование успешно перемещено", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                DialogResult = true;
                Close();
            }
            else
            {
                MessageBox.Show("Оборудование уже находится в выбранном кабинете", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}