﻿using ComputerEquipmentAccounting.Services;
using System.Windows;
using System.Windows.Controls;

namespace ComputerEquipmentAccounting.Views
{
    public partial class RepairRequestWindow : Window
    {
        private readonly DatabaseService _dbService;
        private readonly int _equipmentId;

        public RepairRequestWindow(int equipmentId, string equipmentName)
        {
            InitializeComponent();
            _dbService = new DatabaseService();
            _equipmentId = equipmentId;
            txtEquipmentName.Text = equipmentName ?? "Неизвестно";
        }

        private void BtnCreate_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtDescription.Text))
            {
                MessageBox.Show("Введите описание неисправности", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Получаем выбранное значение срочности
            string priority = "средний"; // значение по умолчанию
            if (cmbPriority.SelectedItem != null)
            {
                priority = ((ComboBoxItem)cmbPriority.SelectedItem).Content.ToString();
            }

            bool result = _dbService.CreateRepairRequest(_equipmentId, txtDescription.Text, priority);

            if (result)
            {
                MessageBox.Show("Заявка на ремонт успешно создана", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                DialogResult = true;
                Close();
            }
            else
            {
                MessageBox.Show("Ошибка при создании заявки", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}