﻿using System.Windows;

namespace ComputerEquipmentAccounting
{
    public partial class App : Application
    {
        public static string ConnectionString = @"Data Source=C:\Users\pc\source\repos\ComputerEquipmentAccounting\EquipmentDB.db;Version=3;";

        public static User? CurrentUser { get; set; }
    }

    public class User
    {
        public int Id { get; set; }
        public string Login { get; set; } = "";
        public string FullName { get; set; } = "";
        public string Role { get; set; } = "";
    }
}